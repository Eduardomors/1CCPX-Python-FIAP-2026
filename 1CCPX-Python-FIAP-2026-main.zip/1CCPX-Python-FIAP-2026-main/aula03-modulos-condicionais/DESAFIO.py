nome_usuario = input("Digite seu nome: ")
idade_usuario = int(input("Digite sua idade: "))

if idade_usuario < 17:
    print("seu voto é opcional esse ano")
elif idade_usuario >= 18:
    print("seu voto é obrigatório esse ano")
else:
    print("seu voto é opcional esse ano")